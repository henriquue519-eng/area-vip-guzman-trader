
const CACHE = 'guzman-v1';
const TO_CACHE = ['/', '/index.html', '/manifest.json', '/src/styles.css'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(TO_CACHE))); self.skipWaiting(); });
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(cached => cached || fetch(e.request).then(resp => caches.open(CACHE).then(cache => { cache.put(e.request, resp.clone()); return resp; }))));
});
