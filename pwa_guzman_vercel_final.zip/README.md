
Área VIP Guzmán Trader - PWA pronto para Vercel
----------------------------------------------

Passos rápidos para publicar no Vercel (3 minutos):
1. Faça login em https://vercel.com (crie conta gratuita se necessário).
2. No Vercel, clique em "New Project" → "Import from Git Repository".
   - Se não usa Git: crie um repositório no GitHub/GitLab e dê push do código deste projeto.
3. Aponte para o repositório; o Vercel detecta Vite automaticamente.
   - Build command: `npm run build`
   - Output directory: `dist`
4. Clique em "Deploy". Em poucos segundos terá o link do seu site PWA.

Se preferir, pode fazer upload manual (Upload) do diretório do projeto via "New Project" → "Upload".
