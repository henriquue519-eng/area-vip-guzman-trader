
export const AFFILIATE_LINK = "https://trade.bull-ex.com/register?aff=761333&aff_model=revenue&afftrack=";
