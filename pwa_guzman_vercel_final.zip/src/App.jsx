
import React, {useEffect, useState} from 'react';
import signalsData from './data/mock-signals';
import SignalCard from './components/SignalCard';
import { AFFILIATE_LINK } from './config';

export default function App(){
  const [user, setUser] = useState(null);
  const [signals, setSignals] = useState([]);
  useEffect(()=>{
    setSignals(signalsData);
    const s = localStorage.getItem('user');
    if(s) setUser(JSON.parse(s));
  },[]);
  const login = (name)=>{ const u={name:name||'Titán'}; localStorage.setItem('user', JSON.stringify(u)); setUser(u); };
  const logout = ()=>{ localStorage.removeItem('user'); setUser(null); };
  return (
    <div className="app">
      <header className="topbar"><div className="brand">Área VIP Guzmán Trader</div><div>{user? <button className="link" onClick={logout}>Sair</button>:null}</div></header>
      <main className="content">
        {!user ? (
          <div className="card center"><h2>Bem-vindo</h2><p>Entre para ver sinais em tempo real e ofertas exclusivas.</p>
          <button className="primary" onClick={()=>login('Guzman')}>Entrar como Guzman</button>
          <button className="secondary" onClick={()=>login('Visitante')}>Continuar como visitante</button></div>
        ) : (
          <>
            <div className="actions"><a className="cta" href={AFFILIATE_LINK} target="_blank" rel="noreferrer">Abrir Corretora</a></div>
            <section className="signals-list">{signals.map(s=> <SignalCard key={s.id} signal={s} />)}</section>
          </>
        )}
      </main>
      <footer className="footer">© {new Date().getFullYear()} Área VIP Guzmán Trader</footer>
    </div>
  );
}
