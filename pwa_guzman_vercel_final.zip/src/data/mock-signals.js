
const data = [
  { id:'s1', asset:'BTC/USDT', price:73450.23, direction:'COMPRA', timeframe:'1M', note:'Entrada confirmada', posted_by:'Guzman', posted_at:new Date().toISOString() },
  { id:'s2', asset:'ETH/USDT', price:3450.12, direction:'VENDA', timeframe:'5M', note:'Atenção suporte próximo', posted_by:'Equipe', posted_at:new Date().toISOString() }
];
export default data;
