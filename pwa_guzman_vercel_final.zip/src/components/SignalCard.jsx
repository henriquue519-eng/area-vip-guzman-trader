
import React from 'react';
export default function SignalCard({signal}){
  const {asset,price,direction,timeframe,note,posted_by}=signal;
  const isBuy = String(direction).toLowerCase().includes('compra') || String(direction).toLowerCase().includes('buy');
  return (
    <article className={`signal ${isBuy?'buy':'sell'}`}>
      <div className="row"><div className="asset">{asset} • {timeframe}</div><div className="by">Por {posted_by}</div></div>
      <div className="row"><div className="price">{price.toLocaleString ? price.toLocaleString() : price}</div><div className="dir">{direction}</div></div>
      {note ? <div className="note">{note}</div>:null}
    </article>
  );
}
